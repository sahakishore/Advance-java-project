import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/ViewServlet")  
public class ViewServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
               throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        out.print("<head>");
        out.print("<style>");
        out.print("a:link {\n" +
"    color: red;\n" +
"}\n" +
"\n" +
"/* visited link */\n" +
"a:visited {\n" +
"    color: green;\n" +
"}\n" +
"\n" +
"/* mouse over link */\n" +
"a:hover {\n" +
"    color: hotpink;\n" +
"}\n" +
"\n" +
"/* selected link */\n" +
"a:active {\n" +
"    color: blue;\n" +
"}"
                + "table {\n" +
"    border-collapse: collapse;\n" +
"    width: 100%;\n" +
"}\n" +
"\n" +
"th, td {\n" +
"    text-align: left;\n" +
"    padding: 8px;\n" +
"}\n" +
"\n" +
"tr:nth-child(even){background-color: #f2f2f2}\n" +
"\n" +
"th {\n" +
"    background-color: #4CAF50;\n" +
"    color: white;\n" +
"}");
        out.print("</style>");
        out.print("</head>");
        out.println("<a href='index.html'>Add New Employee</a>");  
        out.println("<h1>Employees List</h1>");  
          
        List<Emp> list=EmpDao.getAllEmployees();  
       out.print("<body style=\"background-image: url('image/b.jpeg'); background-repeat: no-repeat; width: 100%\">");   
        out.print("<table border='1' width='100%'");  
        out.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Country</th><th>Edit</th><th>Delete</th></tr>");  
        for(Emp e:list){ 
            out.print("<tr><td>"+e.getId()+"</td><td>"+e.getName()+"</td><td>"+e.getPassword()+"</td>  <td>"+e.getEmail()+"</td><td>"+e.getCountry()+"</td><td><a href='EditServlet?id="+e.getId()+"'>edit</a></td>  <td><a href='DeleteServlet?id="+e.getId()+"'>delete</a></td></tr>");  
        }  
        out.print("</table>");  
          out.print("</body>");
        out.close();  
    }  
}  
