import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/EditServlet")  
public class EditServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
           throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        out.println("<h1>Update Employee</h1>");  
        String sid=request.getParameter("id");  
        int id=Integer.parseInt(sid);  
          
        Emp e=EmpDao.getEmployeeById(id);  
         out.print("<head>");
        out.print("<style>");
        out.print("a:link {\n" +
"    color: red;\n" +
"}\n" +
"\n" +
"/* visited link */\n" +
"a:visited {\n" +
"    color: green;\n" +
"}\n" +
"\n" +
"/* mouse over link */\n" +
"a:hover {\n" +
"    color: hotpink;\n" +
"}\n" +
"\n" +
"/* selected link */\n" +
"a:active {\n" +
"    color: blue;\n" +
"}"
                + "table {\n" +
"    border-collapse: collapse;\n" +
"    width: 100%;\n" +
"}\n" +
"\n" +
"th, td {\n" +
"    text-align: left;\n" +
"    padding: 8px;\n" +
"}\n" +
"\n" +
"tr:nth-child(even){background-color: #f2f2f2}\n" +
"\n" +
"th {\n" +
"    background-color: #4CAF50;\n" +
"    color: white;\n" +
"}");
        out.print("</style>");
        out.print("</head>");
       out.print("<body style=\"background-image: url('image/c.jpg'); background-repeat: no-repeat; width: 100%\">"); 
        out.print("<form action='EditServlet2' method='post'>");  
        out.print("<table>");  
        out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
        out.print("<tr><td>Name:</td><td><input type='text' name='name' value='"+e.getName()+"'/></td></tr>");  
        out.print("<tr><td>Password:</td><td><input type='password' name='password' value='"+e.getPassword()+"'/></td></tr>");  
        out.print("<tr><td>Email:</td><td><input type='email' name='email' value='"+e.getEmail()+"'/></td></tr>");  
        out.print("<tr><td>Country:</td><td>");  
        out.print("<select name='country' style='width:150px'>");  
        out.print("<option>India</option>");  
        out.print("<option>USA</option>");  
        out.print("<option>UK</option>");  
        out.print("<option>Other</option>");  
        out.print("</select>");  
        out.print("</td></tr>");  
        out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");  
        out.print("</table>");  
        out.print("</form>");  
        
      out.print("</body>");
        out.close();  
    }  
}  
