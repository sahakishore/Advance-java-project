create table kishor(id number(30) not null, name varchar2(4000), password varchar2(4000), email varchar2(4000), country varchar2(4000), primary key(id));

